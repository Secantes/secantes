/*
	Video Controller jQuery plugin

	Creates a universal controller for multiple video types and providers
*/
;(function($) {

	"use strict";